#ifndef COMMAND_RECEIVER_H_
#define COMMAND_RECEIVER_H_

int command_receiver();

#endif /* COMMAND_RECEIVER_H_ */
