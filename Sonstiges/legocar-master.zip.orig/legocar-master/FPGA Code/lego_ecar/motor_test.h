#ifndef MOTORTEST_H_
#define MOTORTEST_H_

int motor_test();

#endif /* MOTORTEST_H_ */
